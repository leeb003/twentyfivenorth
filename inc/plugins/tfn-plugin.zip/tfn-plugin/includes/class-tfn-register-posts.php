<?php
/**
  * Register custom post types used in our plugin, Agents, Portfolio & Testimonials
  */

    class TFN_Register_Posts {
        // properties

        // methods
        public function __construct() {
            //add_action('init', array($this, 'register_posts'));

		}

		public function register_posts() {
            // photos
            $photo_labels = array(
                'name'               => __('Photo Item', 'tfn-plugin'),
                'menu_name'          => __('Photo Entries', 'tfn-plugin'),
                'add_new'            => __('Add new', 'tfn-plugin'),
                'add_new_item'       => __('Add New Photo Entry', 'tfn-plugin'),
                'edit_item'          => __('Edit Photo Entry', 'tfn-plugin'),
                'new_item'           => __('New Photo Entry', 'tfn-plugin'),
                'view_item'          => __('View Photo Entry', 'tfn-plugin'),
                'search_items'       => __('Search Photos', 'tfn-plugin'),
                'not_found'          => __('No Photo Entries Found', 'tfn-plugin'),
                'not_found_in_trash' => __('No Photo Entries found in Trash', 'tfn-plugin'),
                'parent_item_colon'  => ''
            );

            $photo_args = array(
                'labels'             => $photo_labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'query_var'          => true,
                'rewrite'            => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'capability_type'    => 'post',
                'taxonomies'         => array('photo_entry'),
                'supports'           => array('title', 'editor', 'thumbnail', 'author', 'comments' ),
                'exclude_from_search'=> true,
                'menu_icon'          => 'dashicons-grid-view'
            );

            register_post_type('photo_entry', $photo_args);

            // register the custom photo taxonomy
            register_taxonomy('tfnphotocat',
                'photo_entry',
                array(
                    'label' => __('Photo Category', 'tfn-plugin'),
                    'rewrite' => array(),
                    'capabilities' => array(),
					'show_admin_column' => true,
                )
            );
        }
	} // end class
