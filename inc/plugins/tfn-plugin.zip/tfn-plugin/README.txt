=== Plugin Name ===
Contributors: sh-themes
Tags: WordPress, plugin, 25North
Requires at least: 4.5
Tested up to: 4.5.3
Stable tag: 4.5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Twenty Five North Plugin is a plugin that includes functionality for the Twenty Five North WordPress Theme

== Description ==

Twenty Five North Plugin is a plugin that includes functionality for the Twenty Five North WordPress Theme.  This plugin
includes custom post types and general features that are included with the
theme incorporated into this plugin so you will still have access to these
features away from the theme.

== Installation ==

Installing the Twenty Five North Plugin can be done by using the following steps:

Plugin can be installed, activated, and updated under your plugins section when Twenty Five North is activated.


== Frequently Asked Questions ==
= What does this plugin do? =
This plugin contains added functionality for the WordPress Themes we create.  It includes several custom post types and features tha
t come along with the theme.

== Changelog ==

= 1.0 =
* Initial Release

== Upgrade Notice ==
